package com.tienda.services;

import java.util.List;

import com.tienda.entities.PedidosEntity;


public interface PedidosService {
	
	public List<PedidosEntity> encontraPedidos();

}
