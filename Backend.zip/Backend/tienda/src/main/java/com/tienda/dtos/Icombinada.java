package com.tienda.dtos;

import lombok.Getter;

@Getter
public interface Icombinada {
	 String getNombre();
	 String getApellido();
	 String getCalle();
	 String getNumero();
	

}
