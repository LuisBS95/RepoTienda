package com.tienda.services;

import java.util.List;

import com.tienda.entities.DireccionEntity;



public interface DireccionService {

	
	public List<DireccionEntity> encontraDirecciones();
}
